# Oto Yayın

Oto Yayın, video içeriklerini tek bir yerden yönetmenize yardımcı olan Windows masaüstü uygulamasıdır. Yerel bilgisayarınızda video dosyalarını düzenlemenizi, yapay zeka destekli metin hazırlama araçları (Ollama) kullanarak başlık ve açıklamalar oluşturmamızı ve desteklenen sosyal platformların resmi API'leri üzerinden yayın iş akışını yönetmenizi sağlar.

> **Önemli Not:** Oto Yayın bağımsız bir masaüstü yazılımıdır. YouTube, TikTok veya Instagram tarafından geliştirilmemiş ya da onaylanmış değildir.

## Özellikler

*   **Yerel Video Yönetimi:** Bilgisayarınızda bulunan video dosyalarını listeleyebilir ve düzenleyebilirsiniz.
*   **Yapay Zeka Destekli Metin Hazırlama:** Yerel Ollama kurulumu üzerinden platforma uygun başlık, açıklama ve etiket metinleri oluşturabilirsiniz.
*   **Sosyal Platform Entegrasyonları:** YouTube, TikTok veya Instagram gibi desteklenen sosyal platformların resmi API'leri üzerinden içerik yükleme ve kuyruğu yönetimi.
*   **İçerik Akışı Takibi:** Video dosya yolları, süre, çözünürlük ve boyut gibi medya bilgilerini takip edebilir ve yayın kuyruğunu zamanlayabilirsiniz.

## Kullanılan Teknolojiler

Verilen kaynak kodları ve dökümanlardaki referanslara dayanarak aşağıdaki teknolojilerin kullanıldığı veya uygulamanın çalışması için gerekli olduğu tespit edilmiştir:

*   **Frontend:** HTML5, CSS3 (Modern CSS değişkenleri, Flexbox/Grid yapıları).
*   **Yerel AI Motoru:** Ollama (Metin üretimi ve başlık oluşturma işlemleri için).
*   **Medya İşleme:** FFmpeg ve FFprobe (Video dosyaları üzerinde işlem yapabilmek için).
*   **API Entegrasyonları:** Sosyal medya platformlarının resmi API'leri (OAuth, Client Secret vb. mekanizmaları).

## Proje Yapısı

```text
oto_yayin_website/
├── assets/
│   ├── oto-yayin-icon.png
│   └── site.css
├── index.html
├── privacy.html
├── support.html
└── terms.html
```

## Kurulum / Çalıştırma

Verilen dosya listesi ve kod örnekleri arasında kurulum betikleri, paket yöneticisi dosyaları (örn. `requirements.txt`, `package.json`) veya derleme komutları bulunmamaktadır. Bu proje bir Windows masaüstü uygulamasının web arayüzünü veya dökümantasyonunu içermektedir.

*   **Kurulum Bilgisi:** Verilen kaynaklarda kurulum adımları yer almamaktadır. Uygulamayı çalıştırmak için resmi dağıtım paketi (installer) veya işletim sistemi gereksinimleri destek sayfasından (`support.html`) kontrol edilmelidir.
*   **Gereksinimler:** Uygulamanın tam olarak çalışması için bilgisayarınızda yerel bir Ollama kurulumu ve FFmpeg'in PATH içinde olması gerektiği belirtilmiştir.

## Kullanım

1.  **Başlatma:** Uygulamayı Windows ortamında başlatın.
2.  **Video Ekleme:** Yerel video klasörlerinizi seçerek içeriği sisteme ekleyin.
3.  **Metin Oluşturma:** Ollama bağlantısını yapılandırarak videolar için otomatik başlık ve açıklama oluşturun.
4.  **API Bağlantısı:** Desteklenen sosyal medya platformları için gerekli olan Client Key/Secret veya OAuth token bilgilerini ayarlara ekleyin.
5.  **Yayın Yönetimi:** Oluşturulan içerikleri kuyruğa ekleyerek planlı yayınlar yapın.

## Gizlilik ve Yasal Bilgiler

*   **Gizlilik Politikası:** Uygulamanın yerel olarak işlediği veriler (video yolları, SHA-256 özetleri, medya bilgileri) ve üçüncü taraf hizmetlerle paylaşılan veriler `privacy.html` dosyasında detaylandırılmıştır.
*   **Kullanım Şartları:** Uygulamayı kullanarak bu şartları kabul etmiş olursunuz. Yüklenen içeriklerin telif haklarına uygun olduğundan ve platform kurallarına uyduğunuzdan sorumlusunuz.

## Katkıda Bulunma

Bu proje bağımsız bir masaüstü yazılımıdır. Kod tabanı veya açık kaynak katkısı için spesifik talimatlar mevcut dosyalarda yer almamaktadır. Sorularınız, hata bildirimleriniz veya önerileriniz için `support.html` sayfasında belirtilen iletişim kanallarını kullanabilirsiniz.
